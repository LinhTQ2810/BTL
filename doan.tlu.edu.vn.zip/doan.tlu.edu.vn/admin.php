<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>.: Giáo vụ - 	Quản lí đồ án :.</title>
		<?php require "Includes/layout/Shared/header.php";?>
	</HEAD>
	<BODY>
		<?php require "Includes/layout/Shared/menu_logo.php";?>
		<div class="container-home">
			<?php require "Includes/layout/Shared/menu_trai_admin.php";?>
			<?php require "Includes/layout/Shared/home_phai_admin.php";?>
		</div>
	</BODY>
	<FOOTER>
		<?php require "Includes/layout/Shared/footer.php";?>
	</FOOTER>

	<script>
		function datthoigian(){
			$("#important_news_admin").load("http://localhost/doan.tlu.edu.vn/Pages/datthoigian.html")
		}

		function doandangthuchien(){
			$("#important_news_admin").load("http://localhost/doan.tlu.edu.vn/Pages/danhsachdoandangthuchien.html")
		}

		function doandahoanthanh(){
			$("#important_news_admin").load("http://localhost/doan.tlu.edu.vn/Pages/doandahoanthanh.html")
		}

		function huydoan(){
			$("#important_news_admin").load("http://localhost/doan.tlu.edu.vn/Pages/huydoan.html")
		}

		function thongtinsinhvien(){
			$("#important_news_admin").load("http://localhost/doan.tlu.edu.vn/Pages/thongtinsinhvien.html")
		}

		function thaotacsinhvien(){
			$("#important_news_admin").load("http://localhost/doan.tlu.edu.vn/Pages/thaotacsinhvien.html")
		}

		function ytuongsinhvien(){
			$("#important_news_admin").load("http://localhost/doan.tlu.edu.vn/Pages/ytuongsinhvien.html")
		}

		function thongtingiangvien(){
			$("#important_news_admin").load("http://localhost/doan.tlu.edu.vn/Pages/thongtingiangvien.html")
		}

		function thaotacgiangvien(){
			$("#important_news_admin").load("http://localhost/doan.tlu.edu.vn/Pages/thaotacgiangvien.html")
		}

		function nghiencuugiangvien(){
			$("#important_news_admin").load("http://localhost/doan.tlu.edu.vn/Pages/nghiencuugiangvien.html")
		}

		function xuatbaocao(){
			$("#important_news_admin").load("http://localhost/doan.tlu.edu.vn/Pages/xuatbaocao.html")
		}

		function thanhlaphoidong(){
			$("#important_news_admin").load("http://localhost/doan.tlu.edu.vn/Pages/thanhlaphoidong.html")
		}

		function doimatkhau(){
			$("#important_news_admin").load("http://localhost/doan.tlu.edu.vn/Pages/doimatkhautk.html")
		}
	</script>

	
</HTML>