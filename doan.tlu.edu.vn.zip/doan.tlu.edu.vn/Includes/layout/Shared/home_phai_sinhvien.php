<!-- Main Home -->
	<div class="main-home">
		<!--Begin Center-->
		<div>
			<!--Begin Danh sach cac muc co the duoc hien thi o center-->
			<div id="Panel_center" style="width:100%;">
				<table id="ctl05_MyList" cellspacing="0" cellpadding="0" style="width:100%;border-collapse:collapse;">
					<tbody>
						<tr>
							<td valign="top" style="width:100%;">													
								<div class="box_center" style="postion:relative">								 					
									<h4>
										<span>Đồ án tốt nghiệp đại học</span>
									</h4>																																
									<div class="content">
										<div id="important_news" >



										</div>																	
									
									
																			
										
									</div>
								</div>									
							</td>
						</tr>
					</tbody>
				</table> 

			</div>
		
		</div>
		
	</div>

	