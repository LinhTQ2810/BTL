<div style="float:left;margin-top:60px;width:100%">
	<div id="footer_1" align="left">
		<h4 id="hotline">Ðường dây nóng<br>
			<span id="PageFooter1_lblHotline">04.38521441</span>
		</h4>
		<h4 style="FONT-SIZE:12px;right:11px;POSITION:absolute;TOP:20px">
			<a href="index.php" style="color:White;">Trang chủ</a>
			|
			<a style="color:White;">Đăng nhập</a>
			| <A style="COLOR:white">Hỏi đáp</A>
			| <A style="COLOR:white">Trợ giúp</A>
		</h4>
	</div>