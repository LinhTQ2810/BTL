<form method="post" action="" id="Form1">
<div id="headerright">
	<div id="header">
		
		<div style="POSITION: absolute;FONT-FAMILY: -webkit-body;COLOR: white;FONT-SIZE: 18px;TOP: 32px;FONT-WEIGHT: bold;LEFT: 8px">
			<span id="PageHeader1_lblWebtitle">HỆ THỐNG QUẢN LÍ ĐỒ ÁN TỐT NGHIỆP KHOA CNTT - ĐẠI HỌC THỦY LỢI</span>
		</div>

		<span id="navbar"><a href="index.php" >Trang chủ</a> |
			<a id="PageHeader1_SignOut_ibnLogout" href="" style="color:White;">Đăng nhập</a>

			| <a href="" >Hỏi đáp</a> | <a href="" >
				Trợ giúp</a>
		</span>

		<DIV id="box_size">
			<SPAN id="ur" style="FONT-SIZE: 14px; FONT-WEIGHT: bold"></SPAN></DIV>
		<DIV id="box_user">
			<div id="PageHeader1_Panel1" style="width:400px;TEXT-ALIGN: right; MARGIN-TOP: 2px">
				<P>
					<span id="PageHeader1_lblUserFullName" style="color:Blue;font-size:10px;font-weight:bold;">Khách</span>
					<span id="PageHeader1_lblRoleTitle"></span>
					<span id="PageHeader1_lblUserRole" style="color:Blue;font-size:10px;"></span>
					<a id="PageHeader1_lbNewmessage" href="javascript:WebForm_DoPostBackWithOptions(new WebForm_PostBackOptions(&quot;PageHeader1$lbNewmessage&quot;, &quot;&quot;, true, &quot;&quot;, &quot;&quot;, false, true))" style="color:Blue;background-color:Transparent;FONT-SIZE: 10px"></a>
				</P></div>
			</DIV>
	</div>
</div>

</form>

<div id="searchbox">
	<div style="PADDING-BOTTOM: 0px; PADDING-LEFT: 8px; PADDING-RIGHT: 0px; PADDING-TOP: 8px"></div>
	
</div>