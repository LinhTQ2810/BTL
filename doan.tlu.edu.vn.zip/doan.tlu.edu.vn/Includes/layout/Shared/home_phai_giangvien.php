<!-- Main Home -->
	<div class="main-home">
		<!--Begin Center-->
		<div>
			<!--Begin Danh sach cac muc co the duoc hien thi o center-->
			<div id="Panel_center" style="width:100%;">
			<table id="ctl05_MyList" cellspacing="0" cellpadding="0" style="width:100%;border-collapse:collapse;">
				<tbody><tr>
					<td valign="top" style="width:100%;">													
						<div class="box_center" style="postion:relative">								 					
							<h4>
							<span>Quản lí đồ án sinh viên  
							<span style="position:absolute;right:5px">
								<a style="color:white;text-decoration:none;font-size:12px;text-transform:none" href=""><b>Xem tất cả</b></a></span>
							</span>
							</h4>																																
							<div class="content">
								<div id="important_news_gv" >																	
								 
								</div>											
															
								
								
							</div>
						</div>									
					</td>
				</tr>
			</tbody>
		</table> 

		</div>
		<!--End Danh sach cac muc co the duoc hien thi o center-->
	</div>
		<!--End Center-->
	</div>

